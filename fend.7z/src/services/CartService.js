import axios from 'axios';

const CART_API_BASE_URL = "http://localhost:8080/api/v1/cartproducts";

class CartService {

    getCarts(){
        return axios.get(CART_API_BASE_URL);
    }

    createCart(cart){
        return axios.post(CART_API_BASE_URL, cart);
    }

    getCartById(cartId){
        return axios.get(CART_API_BASE_URL + '/' + cartId);
    }

    updateCart(cart, cartId){
        return axios.put(CART_API_BASE_URL + '/' + cartId, cart);
    }

    deleteCart(cartId){
        return axios.delete(CART_API_BASE_URL + '/' + cartId);
    }
}

export default new CartService()