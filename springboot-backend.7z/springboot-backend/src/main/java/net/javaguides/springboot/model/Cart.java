package net.javaguides.springboot.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cartproducts")
public class Cart {

    
}
