package net.javaguides.springboot.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cartproducts")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long CartId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_price")
    private long productPrice;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Product> products = new ArrayList<Product>();


    public Cart() { }

    public Cart(String productName, long productPrice) {
        this.productName = productName;
        this.productPrice = productPrice;
    }

    public long getCartId() {
        return CartId;
    }

    public void setCartId(long cartId) {
        CartId = cartId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public long getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(long productPrice) {
        this.productPrice = productPrice;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}