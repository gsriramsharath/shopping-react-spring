package net.javaguides.springboot.DOT;

public class productDTO {
}
