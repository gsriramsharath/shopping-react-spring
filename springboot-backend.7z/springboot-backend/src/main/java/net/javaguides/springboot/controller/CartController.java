package net.javaguides.springboot.controller;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Cart;
import net.javaguides.springboot.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class CartController {

    @Autowired
    private CartRepository cartRepository;

    @GetMapping("/carts")
    public List<Cart> getAllCart(){
        return cartRepository.findAll();
    }

    @PostMapping("/carts")
    public Cart createCart(@RequestBody Cart cart){
        return cartRepository.save(cart);
    }

    @GetMapping("/carts/{id}")
    public ResponseEntity<Cart>getCartId(@PathVariable Long id){
        Cart cart = cartRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cart not exist with id :" + id));
        return ResponseEntity.ok(cart);
    }

    @PutMapping("/carts/{id}")
    public ResponseEntity<Cart> updateCart(@PathVariable Long id, @RequestBody Cart cartDetails){
        Cart cart = cartRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("cart not exist with id :" + id));

        cart.setProductName(cartDetails.getProductName());
        cart.setProductPrice(cartDetails.getProductPrice());

        Cart updatedCart = cartRepository.save(cart);
        return ResponseEntity.ok(updatedCart);
    }

    // delete cart rest api
    @DeleteMapping("/carts/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteCart(@PathVariable Long id){
        Cart cart = cartRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cart not exist with id :" + id));

        cartRepository.delete(cart);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
}
